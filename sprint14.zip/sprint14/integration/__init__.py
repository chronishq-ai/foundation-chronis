"""
Integration package initialization.
"""
