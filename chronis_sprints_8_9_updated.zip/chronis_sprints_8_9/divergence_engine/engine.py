"""Sprint 8 — production Divergence Engine entry points.

Production inputs come from Sprint 3 HSSM and Sprint 7 NSSM ``RegimeSeries``
objects.  The synthetic arrays under ``synthetic/`` are validation fixtures only
and are never accepted by the upstream adapter as production evidence.
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple
import numpy as np

from upstream_interfaces import RegimeSeries
from .state import DivergenceState, Provenance, compute_type_scores
from .cooccupancy import fisher_cooccupancy_test, CooccupancyResult
from .granger import within_regime_granger_test, GrangerResult


@dataclass(frozen=True)
class DivergenceInputs:
    """Validated aligned HSSM/NSSM data for one domain/window.

    ``m_t`` and ``n_t`` are retained as complete matrices. The engine never
    scalarizes them. For real execution use ``from_upstream``.
    """
    user_id: str
    domain_id: str
    window_start: datetime
    window_end: datetime
    p_t: np.ndarray
    q_t: np.ndarray
    m_t: np.ndarray
    n_t: np.ndarray
    behavioral_regime_id: int
    narrative_regime_id: int
    n_domain_pairs_tested: int
    behavioral_attractor_weakening: bool
    narrative_conformal_confidence: float
    claim_influence_discount: float = 0.0
    upstream_source: str = "HSSM+NSSM"
    synthetic_validation: bool = False

    @classmethod
    def from_upstream(
        cls,
        behavioral: RegimeSeries,
        narrative: RegimeSeries,
        *,
        domain_id: str,
        behavioral_regime_id: int,
        narrative_regime_id: int,
        n_domain_pairs_tested: int,
        behavioral_attractor_weakening: bool,
        narrative_conformal_confidence: float,
        claim_influence_discount: float = 0.0,
    ) -> "DivergenceInputs":
        """Build inputs only from real HSSM/NSSM-shaped upstream outputs."""
        behavioral.validate_for_divergence()
        narrative.validate_for_divergence()
        if behavioral.user_id != narrative.user_id:
            raise ValueError("HSSM and NSSM outputs must belong to the same user")
        if behavioral.system != "behavioral" or narrative.system != "narrative":
            raise ValueError("Expected behavioral HSSM and narrative NSSM RegimeSeries")
        if list(behavioral.session_ids) != list(narrative.session_ids):
            raise ValueError("HSSM/NSSM session IDs are not aligned")
        if list(behavioral.timestamps) != list(narrative.timestamps):
            raise ValueError("HSSM/NSSM timestamps are not aligned")
        return cls(
            user_id=behavioral.user_id,
            domain_id=domain_id,
            window_start=min(behavioral.timestamps),
            window_end=max(behavioral.timestamps),
            p_t=np.asarray(behavioral.regime_labels, dtype=int),
            q_t=np.asarray(narrative.regime_labels, dtype=int),
            m_t=np.asarray(behavioral.fast_state, dtype=float),
            n_t=np.asarray(narrative.fast_state, dtype=float),
            behavioral_regime_id=behavioral_regime_id,
            narrative_regime_id=narrative_regime_id,
            n_domain_pairs_tested=n_domain_pairs_tested,
            behavioral_attractor_weakening=behavioral_attractor_weakening,
            narrative_conformal_confidence=narrative_conformal_confidence,
            claim_influence_discount=claim_influence_discount,
            upstream_source="HSSM+NSSM",
            synthetic_validation=False,
        )

    def validate(self) -> None:
        if len(self.p_t) != len(self.q_t) or len(self.p_t) != len(self.m_t) or len(self.p_t) != len(self.n_t):
            raise ValueError("p_t, q_t, m_t and n_t must share the same session axis")
        if len(self.p_t) < 1:
            raise ValueError("Divergence window cannot be empty")
        if np.asarray(self.m_t).ndim != 2 or np.asarray(self.n_t).ndim != 2:
            raise ValueError("m_t and n_t must remain multivariate matrices shaped (T, d)")
        if self.n_domain_pairs_tested < 1:
            raise ValueError("n_domain_pairs_tested must be >= 1")


def _slice_to_joint_regime_window(m_t, n_t, p_t, q_t, behavioral_regime_id, narrative_regime_id):
    joint_mask = (p_t == behavioral_regime_id) & (q_t == narrative_regime_id)
    return m_t[joint_mask], n_t[joint_mask]


def compute_divergence_state(
    inputs: DivergenceInputs,
    previous_state_id: Optional[str] = None,
    *,
    allow_synthetic: bool = False,
) -> DivergenceState:
    inputs.validate()
    if inputs.synthetic_validation and not allow_synthetic:
        raise ValueError(
            "Synthetic regime arrays are validation-only. Use DivergenceInputs.from_upstream() "
            "for the real HSSM→NSSM→Divergence path, or explicitly opt into synthetic validation."
        )
    cooc: CooccupancyResult = fisher_cooccupancy_test(
        inputs.p_t, inputs.q_t, inputs.behavioral_regime_id,
        inputs.narrative_regime_id, n_pairs_tested=inputs.n_domain_pairs_tested,
    )
    m_in_regime, n_in_regime = _slice_to_joint_regime_window(
        inputs.m_t, inputs.n_t, inputs.p_t, inputs.q_t,
        inputs.behavioral_regime_id, inputs.narrative_regime_id,
    )
    granger: GrangerResult = within_regime_granger_test(
        m_in_regime, n_in_regime, n_pairs_tested=inputs.n_domain_pairs_tested,
    )

    cooc_strength = 1.0 if cooc.significant else 0.0
    narrative_leads = granger.significant_n_causes_m if granger.ran else False
    behavioral_leads = granger.significant_m_causes_n if granger.ran else False
    bidirectional = narrative_leads and behavioral_leads
    shared_driver_gate = bool(cooc.significant and granger.ran and (narrative_leads or behavioral_leads))

    # D-family evidence formulas. They are deliberately bounded and transparent;
    # a shared-driver gate is recorded separately and is consumed by Claim Level 2.
    ignorance_evidence = (1.0 - cooc_strength) * (1.0 if not (narrative_leads or behavioral_leads) else 0.3)
    aspiration_evidence = (
        (1.0 if inputs.behavioral_attractor_weakening else 0.0)
        * (1.0 if narrative_leads and not behavioral_leads else 0.4)
    )
    self_protection_evidence = (
        cooc_strength
        * (1.0 if (not inputs.behavioral_attractor_weakening) and granger.ran and not bidirectional else 0.3)
    )
    active_transition_evidence = (
        (1.0 if inputs.behavioral_attractor_weakening else 0.5)
        * (1.0 if bidirectional else 0.2)
    )
    type_scores = compute_type_scores(
        ignorance_evidence=ignorance_evidence,
        aspiration_evidence=aspiration_evidence,
        self_protection_evidence=self_protection_evidence,
        active_transition_evidence=active_transition_evidence,
        claim_influence_discount=inputs.claim_influence_discount,
    )
    provenance = Provenance(
        fisher_p_value=cooc.p_value,
        fisher_bonferroni_alpha=cooc.bonferroni_alpha,
        granger_f_stat=granger.f_statistic_n_causes_m if granger.ran else None,
        granger_p_value=granger.p_value_n_causes_m if granger.ran else None,
        granger_bonferroni_alpha=granger.bonferroni_alpha,
        lag_order=granger.lag_order,
        n_behavioral_sessions_in_regime=len(m_in_regime),
        n_narrative_sessions_in_regime=len(n_in_regime),
        power_gate_passed=granger.power_gate_passed,
        shared_driver_gate_passed=shared_driver_gate,
        behavioral_state_dim=granger.behavioral_state_dim,
        narrative_state_dim=granger.narrative_state_dim,
        state_preserved_multivariate=granger.tested_multivariate,
        upstream_source=inputs.upstream_source,
        estimator=granger.estimator,
    )
    return DivergenceState.new(
        user_id=inputs.user_id, domain_id=inputs.domain_id,
        window_start=inputs.window_start, window_end=inputs.window_end,
        type_scores=type_scores, confidence=inputs.narrative_conformal_confidence,
        provenance=provenance, previous_state_id=previous_state_id,
    )


def level2_claim_permitted(state: DivergenceState) -> bool:
    return bool(state.provenance.power_gate_passed and state.provenance.shared_driver_gate_passed)
