"""Sprint 8 Day 22 — append-only DivergenceState and explicit evidence formulas."""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
import uuid

AMBIGUITY_THRESHOLD = 0.15


@dataclass(frozen=True)
class TypeScores:
    ignorance: float
    aspiration: float
    self_protection: float
    active_transition: float

    def __post_init__(self) -> None:
        values = (self.ignorance, self.aspiration, self.self_protection, self.active_transition)
        if any(v < 0.0 or v > 1.0 for v in values):
            raise ValueError("Divergence type scores must be in [0, 1]")

    def dominant(self) -> Optional[str]:
        scored = sorted(
            [("ignorance", self.ignorance), ("aspiration", self.aspiration),
             ("self_protection", self.self_protection), ("active_transition", self.active_transition)],
            key=lambda kv: kv[1], reverse=True,
        )
        top_name, top_val = scored[0]
        _, second_val = scored[1]
        if (top_val - second_val) < AMBIGUITY_THRESHOLD:
            return None
        return top_name


@dataclass(frozen=True)
class Provenance:
    """Audit trail for every material statistic used by DivergenceState."""
    fisher_p_value: Optional[float]
    fisher_bonferroni_alpha: Optional[float]
    granger_f_stat: Optional[float]
    granger_p_value: Optional[float]
    granger_bonferroni_alpha: Optional[float]
    lag_order: Optional[int]
    n_behavioral_sessions_in_regime: int
    n_narrative_sessions_in_regime: int
    power_gate_passed: bool
    shared_driver_gate_passed: bool = False
    behavioral_state_dim: int = 0
    narrative_state_dim: int = 0
    state_preserved_multivariate: bool = False
    upstream_source: str = "HSSM+NSSM"
    estimator: str = "VAR-block"
    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=True)
class DivergenceState:
    """Canonical append-only D-family record. A later observation chains via previous_state_id."""
    state_id: str
    user_id: str
    domain_id: str
    observation_window_start: datetime
    observation_window_end: datetime
    type_scores: TypeScores
    confidence: float
    provenance: Provenance
    previous_state_id: Optional[str] = None

    @staticmethod
    def new(user_id: str, domain_id: str, window_start: datetime, window_end: datetime,
            type_scores: TypeScores, confidence: float, provenance: Provenance,
            previous_state_id: Optional[str] = None) -> "DivergenceState":
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("confidence must be in [0, 1]")
        return DivergenceState(
            state_id=str(uuid.uuid4()), user_id=user_id, domain_id=domain_id,
            observation_window_start=window_start, observation_window_end=window_end,
            type_scores=type_scores, confidence=confidence, provenance=provenance,
            previous_state_id=previous_state_id,
        )


def compute_type_scores(*, ignorance_evidence: float, aspiration_evidence: float,
                        self_protection_evidence: float, active_transition_evidence: float,
                        claim_influence_discount: float = 0.0) -> TypeScores:
    """Normalize the four documented D-family evidence formulas to [0,1].

    The engine supplies bounded evidence terms from co-occupancy, attractor
    trend, and block-Granger directionality. No generated claim text feeds this
    calculation; ``claim_influence_discount`` is the explicit future observer-
    effect hook.
    """
    if not 0.0 <= claim_influence_discount <= 1.0:
        raise ValueError("claim_influence_discount must be in [0, 1]")
    discount = 1.0 - claim_influence_discount
    raw = {
        "ignorance": max(0.0, ignorance_evidence) * discount,
        "aspiration": max(0.0, aspiration_evidence) * discount,
        "self_protection": max(0.0, self_protection_evidence) * discount,
        "active_transition": max(0.0, active_transition_evidence) * discount,
    }
    total = sum(raw.values())
    if total <= 0:
        return TypeScores(0.0, 0.0, 0.0, 0.0)
    return TypeScores(**{k: v / total for k, v in raw.items()})
