"""
Sprint 8 Day 23 — multivariate within-regime Granger testing.

The production path preserves the complete behavioral and narrative fast-state
vectors.  Earlier scaffolding reduced each vector to a mean scalar; that is not
an acceptable substitute for m_t / n_t and is intentionally forbidden here.

The estimator remains a classical VAR/F test because statsmodels does not
provide the directive's Bayesian MS-VAR estimator.  The regime labels are
supplied by HSSM/NSSM and the test is run only inside the requested regime pair.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Sequence
import numpy as np
from statsmodels.tsa.api import VAR

MIN_SESSIONS_PER_REGIME = 20


@dataclass(frozen=True)
class GrangerResult:
    ran: bool
    f_statistic_m_causes_n: Optional[float]
    p_value_m_causes_n: Optional[float]
    f_statistic_n_causes_m: Optional[float]
    p_value_n_causes_m: Optional[float]
    lag_order: Optional[int]
    bonferroni_alpha: Optional[float]
    significant_m_causes_n: bool
    significant_n_causes_m: bool
    n_sessions_in_regime: int
    power_gate_passed: bool
    behavioral_state_dim: int = 0
    narrative_state_dim: int = 0
    tested_multivariate: bool = False
    estimator: str = "not-run"
    error: Optional[str] = None


def power_gate(n_sessions_in_regime: int) -> bool:
    """MP-09: hard gate; fewer than 20 aligned sessions means no test."""
    return n_sessions_in_regime >= MIN_SESSIONS_PER_REGIME


def _as_2d_state(state: np.ndarray, name: str) -> np.ndarray:
    arr = np.asarray(state, dtype=float)
    if arr.ndim == 1:
        arr = arr[:, None]
    if arr.ndim != 2:
        raise ValueError(f"{name} must be shape (T, d); got {arr.shape}")
    if arr.shape[1] < 1:
        raise ValueError(f"{name} must preserve at least one state dimension")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} contains non-finite values")
    return arr


def _select_lag(var_model: VAR, n_sessions: int, max_lag: int, n_equations: int) -> int:
    # Conservative upper bound for a multivariate VAR: each equation estimates
    # n_equations coefficients per lag. At the hard 20-session gate we must
    # still be able to fit a complete block model, so the lag cap depends on d.
    candidate = min(max_lag, max(1, (n_sessions - 2) // max(1, 2 * n_equations + 1)))
    selected = var_model.select_order(candidate).aic
    if selected is None or not np.isfinite(selected):
        return 1
    return max(1, int(selected))


def within_regime_granger_test(
    m_t: np.ndarray,
    n_t: np.ndarray,
    n_pairs_tested: int,
    max_lag: int = 3,
    alpha: float = 0.05,
) -> GrangerResult:
    """Run block Granger tests without scalarizing m_t or n_t.

    ``m_t`` and ``n_t`` are complete aligned fast-state matrices.  A block test
    asks whether all lags of the behavioral block jointly improve prediction of
    the narrative block, and vice versa.  Bonferroni correction is applied over
    the tested domain/regime pairs.
    """
    m = _as_2d_state(m_t, "m_t")
    n = _as_2d_state(n_t, "n_t")
    if len(m) != len(n):
        raise ValueError("m_t and n_t must be aligned to the same session grid")
    if n_pairs_tested < 1:
        raise ValueError("n_pairs_tested must be >= 1")

    n_sessions = len(m)
    d_m, d_n = m.shape[1], n.shape[1]
    if not power_gate(n_sessions):
        return GrangerResult(
            ran=False, f_statistic_m_causes_n=None, p_value_m_causes_n=None,
            f_statistic_n_causes_m=None, p_value_n_causes_m=None,
            lag_order=None, bonferroni_alpha=None,
            significant_m_causes_n=False, significant_n_causes_m=False,
            n_sessions_in_regime=n_sessions, power_gate_passed=False,
            behavioral_state_dim=d_m, narrative_state_dim=d_n,
            tested_multivariate=(d_m > 1 or d_n > 1), estimator="blocked-by-MP-09",
        )

    data = np.column_stack([m, n])
    try:
        model = VAR(data)
        lag_order = _select_lag(model, n_sessions, max_lag, data.shape[1])
        fitted = model.fit(lag_order)
        m_indices = list(range(d_m))
        n_indices = list(range(d_m, d_m + d_n))
        gc_m_to_n = fitted.test_causality(caused=n_indices, causing=m_indices, kind="f")
        gc_n_to_m = fitted.test_causality(caused=m_indices, causing=n_indices, kind="f")
    except Exception as exc:
        # A power-gated dataset can still be numerically unfit.  Do not convert
        # that failure into negative evidence; return an explicit non-run result.
        return GrangerResult(
            ran=False, f_statistic_m_causes_n=None, p_value_m_causes_n=None,
            f_statistic_n_causes_m=None, p_value_n_causes_m=None,
            lag_order=None, bonferroni_alpha=alpha / n_pairs_tested,
            significant_m_causes_n=False, significant_n_causes_m=False,
            n_sessions_in_regime=n_sessions, power_gate_passed=True,
            behavioral_state_dim=d_m, narrative_state_dim=d_n,
            tested_multivariate=(d_m > 1 or d_n > 1), estimator="VAR-block",
            error=str(exc),
        )

    bonferroni_alpha = alpha / n_pairs_tested
    return GrangerResult(
        ran=True,
        f_statistic_m_causes_n=float(gc_m_to_n.test_statistic),
        p_value_m_causes_n=float(gc_m_to_n.pvalue),
        f_statistic_n_causes_m=float(gc_n_to_m.test_statistic),
        p_value_n_causes_m=float(gc_n_to_m.pvalue),
        lag_order=int(lag_order), bonferroni_alpha=bonferroni_alpha,
        significant_m_causes_n=bool(gc_m_to_n.pvalue < bonferroni_alpha),
        significant_n_causes_m=bool(gc_n_to_m.pvalue < bonferroni_alpha),
        n_sessions_in_regime=n_sessions, power_gate_passed=True,
        behavioral_state_dim=d_m, narrative_state_dim=d_n,
        tested_multivariate=(d_m > 1 or d_n > 1), estimator="VAR-block",
    )
