# Sprint 8/9 Update — Mentor Submission Notes

Updated against the supplied Sprint 8 and Sprint 9 execution-pack requirements.

## Sprint 8 changes

- Added a production HSSM→NSSM→Divergence adapter through `DivergenceInputs.from_upstream()`.
- Added strict alignment and fit-set validation for real `RegimeSeries` inputs.
- Preserved complete multivariate `m_t` and `n_t` state matrices.
- Replaced the old scalar-mean Granger substitute with block multivariate VAR causality tests.
- Kept MP-09 as a hard 20-session gate.
- Added an explicit shared-driver gate combining significant co-occupancy with a power-gated Granger direction.
- Added provenance fields for state dimensions, multivariate preservation, estimator, upstream source, power gate, and shared-driver gate.
- Added an explicit production guard so synthetic regime arrays cannot be used accidentally.
- Kept planted profiles as a clearly marked validation-only harness.
- Preserved append-only `DivergenceState` history through `previous_state_id`.

## Sprint 9 changes

- Added the shared-driver proof as a hard Level-2 admissibility gate.
- Kept Level-3 as a five-gate hard AND with no softened fallback.
- Made clinical/sensitive terminology a direct-surfacing safety gate that routes generated text to human review.
- Added explicit `is_canonical_truth=False` metadata to generated insights.
- Added `source_canonical_id` to every citation-chain entry and `canonical_source_ids` to the generated insight.
- Retained the three supporting excerpts + one near-miss requirement.
- Kept Level-3 text on mandatory human-review routing.
- Left retrieval-index internals and identity-graph internals outside the Sprint 9 scope.

## Validation performed

- `PYTHONPATH=. pytest -q` → **38 passed**.
- Synthetic planted-profile validation → all four divergence types clear the >75% per-type accuracy target in the current harness.
- Production-path contract tests verify HSSM/NSSM session alignment and full state-matrix preservation.

## Remaining integration note

The code deliberately labels the current estimator as a multivariate block VAR/F implementation rather than claiming it is a Bayesian MS-VAR. If the signed project specification requires the Bayesian MS-VAR estimator specifically, that estimator must be wired at the integration boundary before final sprint seal.
