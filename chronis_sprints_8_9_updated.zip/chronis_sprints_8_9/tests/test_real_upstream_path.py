from datetime import datetime, timedelta
import numpy as np
import pytest

from upstream_interfaces import RegimeSeries
from divergence_engine.engine import DivergenceInputs


def _series(user, system, ids, ts, labels, state):
    return RegimeSeries(
        user_id=user, system=system, session_ids=ids, timestamps=ts,
        regime_labels=np.asarray(labels, dtype=int), n_regimes=2,
        fast_state=np.asarray(state, dtype=float),
        in_fit_set=np.ones(len(ids), dtype=bool), gated=False,
    )


def test_real_hssm_nssm_adapter_preserves_complete_state():
    n = 25
    ids = [f"s{i}" for i in range(n)]
    ts = [datetime(2026, 1, 1) + timedelta(days=i) for i in range(n)]
    m = np.arange(n * 2, dtype=float).reshape(n, 2)
    x = np.arange(n * 3, dtype=float).reshape(n, 3)
    p = np.array([1] * 20 + [0] * 5)
    q = np.array([1] * 20 + [0] * 5)
    hssm = _series("u1", "behavioral", ids, ts, p, m)
    nssm = _series("u1", "narrative", ids, ts, q, x)
    inputs = DivergenceInputs.from_upstream(
        hssm, nssm, domain_id="d1", behavioral_regime_id=1,
        narrative_regime_id=1, n_domain_pairs_tested=1,
        behavioral_attractor_weakening=False, narrative_conformal_confidence=0.8,
    )
    assert inputs.synthetic_validation is False
    assert inputs.upstream_source == "HSSM+NSSM"
    assert inputs.m_t.shape == (n, 2)
    assert inputs.n_t.shape == (n, 3)


def test_real_adapter_rejects_misaligned_hssm_nssm():
    ids = ["s1", "s2", "s3"]
    ts = [datetime(2026, 1, 1) + timedelta(days=i) for i in range(3)]
    state = np.ones((3, 2))
    hssm = _series("u1", "behavioral", ids, ts, [1, 1, 0], state)
    nssm = _series("u1", "narrative", ["s1", "s3", "s2"], ts, [1, 1, 0], state)
    with pytest.raises(ValueError, match="session IDs are not aligned"):
        DivergenceInputs.from_upstream(
            hssm, nssm, domain_id="d1", behavioral_regime_id=1,
            narrative_regime_id=1, n_domain_pairs_tested=1,
            behavioral_attractor_weakening=False, narrative_conformal_confidence=0.8,
        )
