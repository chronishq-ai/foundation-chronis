# Sprint 8 + Sprint 9 — Divergence Engine & Claims Engine

Reference implementation aligned to the Sprint 8/9 execution-pack requirements shown in the supplied sprint pages.

The important change from the earlier scaffold is that the **production Divergence path is now explicitly HSSM → NSSM → DivergenceState**. The synthetic planted profiles remain available only as a validation harness and are rejected by the production entry point unless a test caller explicitly opts in.

## Sprint 8 — Divergence Engine

### Required Sprint-8 points implemented

| Sprint-pack point | Implementation |
|---|---|
| Divergence formulas | `divergence_engine/engine.py` computes the four bounded D-family evidence terms and normalizes them through `compute_type_scores`. |
| Shared-driver gate | Co-occupancy must be significant **and** a power-gated block-Granger direction must run/significantly support the pair. The result is stored in `Provenance.shared_driver_gate_passed`. |
| Power gate | MP-09 is a hard `>=20` aligned sessions-per-regime gate. Below 20, Granger does not run and Level 2 is blocked. |
| Multivariate state preservation | `m_t` and `n_t` remain complete `(T,d)` matrices. Granger uses a block VAR and joint block-causality tests; there is no mean/first-component scalar substitute. |
| Real HSSM + NSSM consumption | `DivergenceInputs.from_upstream()` consumes validated `RegimeSeries` objects for Sprint 3 HSSM and Sprint 7 NSSM output, including session IDs, timestamps, regime labels, fit-set admission, and full fast-state matrices. |
| No fake regime arrays in production | `DivergenceInputs.synthetic_validation=True` is rejected by default. Planted arrays require the explicit `allow_synthetic=True` test-only opt-in. |
| Append-only state | `DivergenceState` is immutable and can chain to a prior state through `previous_state_id`. |
| D-family provenance | `DivergenceState.provenance` records Fisher/Granger statistics, correction alpha, power/shared-driver gates, state dimensions, estimator, and upstream source. |
| Sprint 8 → Sprint 9 handoff | `DivergenceState` is the canonical input consumed by `claims_engine/claim_levels.py`; Sprint 8 does not own claim wording. |

### HSSM/NSSM production entry point

```python
from divergence_engine.engine import DivergenceInputs, compute_divergence_state

inputs = DivergenceInputs.from_upstream(
    behavioral=hssm_regime_series,
    narrative=nssm_regime_series,
    domain_id="domain-123",
    behavioral_regime_id=2,
    narrative_regime_id=4,
    n_domain_pairs_tested=8,
    behavioral_attractor_weakening=False,
    narrative_conformal_confidence=0.91,
)

state = compute_divergence_state(inputs)
```

`from_upstream()` rejects mismatched users, systems, session IDs, timestamps, fit-set admission, empty series, or non-matrix fast states. This is the intended real execution path.

### Estimator note

The regime-conditioned test uses a **multivariate block VAR/F test**. `statsmodels` does not provide the directive's Bayesian MS-VAR estimator, so this repository does not falsely label the block VAR as Bayesian MS-VAR. If the signed Sprint specification requires joint Bayesian MS-VAR estimation, that estimator remains an integration item rather than being silently approximated.

## Sprint 9 — Claims Engine & Grounded Generation

### Required Sprint-9 points implemented

| Sprint-pack point | Implementation |
|---|---|
| Claim hierarchy | `ClaimLevel.LEVEL_0` through `LEVEL_3` with explicit gate evaluation. |
| Admissibility gates | Level 1 attractor declaration; Level 2 convergence, MP-09, shared-driver proof, dominant-type proof, and domain-confidence floor. |
| Level-3 withholding | Five hard gates are ANDed. A failed gate makes the Level-3 evaluation inadmissible; the surfacing policy withholds inadmissible claims rather than softening them. |
| Sensitive/clinical wording gate | Generated text is scanned for clinical terminology. A hit forces human review and is never treated as clean canonical output. |
| Generated language is not canonical truth | `GeneratedInsight.is_canonical_truth` is always `False`; generated text cannot become a canonical claim merely by being produced. |
| Citation/provenance chain from canonical IDs | Every generated sentence receives a citation-chain entry with `source_session_id` and `source_canonical_id`; the insight also exposes `canonical_source_ids`. |
| Grounded retrieval | Generation requires three highest-contribution supporting excerpts plus exactly one near-miss counter-example. |
| Level-3 review | All Level-3 generated text is routed to the standing human-review path. |
| Scope boundary | No retrieval-index internals or identity-graph implementation is added; those remain upstream/downstream interfaces. |
| Phase-E handoff | Claim/provenance objects provide the E0–E3-style claim exit surface for downstream consumers. |

## Files

- `upstream_interfaces.py` — typed contracts for HSSM/NSSM/Attractor/Domain/session evidence.
- `divergence_engine/state.py` — immutable D-family state, type scores, and provenance.
- `divergence_engine/cooccupancy.py` — Fisher exact co-occupancy with Bonferroni correction.
- `divergence_engine/granger.py` — MP-09 gate and multivariate block-Granger implementation.
- `divergence_engine/engine.py` — real upstream adapter + divergence calculation + Sprint 9 handoff.
- `claims_engine/claim_levels.py` — Level 0–3 claim hierarchy and hard gates.
- `claims_engine/surfacing_policy.py` — surface / UNCLEAR / WITHHOLD policy.
- `claims_engine/grounded_generation.py` — constrained generation, clinical gate, and canonical citation chain.
- `synthetic/planted_profiles.py` — validation-only planted profiles; not production evidence.
- `tests/` — Sprint 8/9 unit and integration-contract tests.

## Validation

```bash
pip install -r requirements.txt
PYTHONPATH=. pytest -q
PYTHONPATH=. python3 synthetic/planted_profiles.py
```

Current local test result after the Sprint 8/9 update: **38 passed**.

The synthetic suite demonstrates the scorer behavior, but it is intentionally not presented as proof of the real HSSM/NSSM exit criteria. Final sprint seal still requires the real Sprint 3/7 outputs and the team's actual surrogate/production data run.

## Explicit handoff boundaries

### Sprint 8 does not own

- HSSM optimizer/convergence/duration defects — those remain Sprint 3 responsibilities.
- Claim wording or generated language — handed to Sprint 9.
- Retrieval-index internals or identity graph — Sprint 9/12-side integration boundary.

### Sprint 9 does not own

- HSSM/NSSM fitting.
- Retrieval-index implementation details.
- Identity-graph implementation details.

## Sign-off checklist

1. Run the real HSSM/NSSM adapter path with the Sprint 3/7 artifacts.
2. Verify the 20-session MP-09 boundary on the real aligned regime windows.
3. Verify shared-driver gate behavior against the signed divergence specification.
4. Run the multivariate state-preservation tests using the actual `m_t`/`n_t` dimensions.
5. Run Sprint 9 Level-0/1/2/3 admissibility and withholding cases.
6. Verify that generated text remains non-canonical and that every sentence has canonical source provenance.
7. Complete any required Bayesian MS-VAR integration if the signed specification requires joint Bayesian estimation before final seal.
